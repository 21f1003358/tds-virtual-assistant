---
title: "RAWgraphs"
original_url: "https://tds.s-anand.net/#/rawgraphs?id=rawgraphs"
downloaded_at: "2025-05-31T21:38:28.850239"
---

[RAWgraphs](#/rawgraphs?id=rawgraphs)
-------------------------------------

[![RAWGraphs 1.0 - Introduction (1 min)](https://i.ytimg.com/vi_webp/2TtYlty-M5g/sddefault.webp)](https://youtu.be/2TtYlty-M5g)

* [RAWgraphs](https://www.rawgraphs.io/)
* [How to make Alluvial Diagram](https://youtu.be/6BYac2Pmnno)
* [How to make Sankey Diagram](https://youtu.be/DYTiKjH6oFM)
* [How to make Beeswarm Plot](https://youtu.be/RPHiEzbCatA)
* [How to make Bump Chart](https://youtu.be/K-weHCSQb58)
* [How to make Circle Packing](https://youtu.be/inm_fR-oykw)
* [How to make Treemap](https://youtu.be/W_MuNYWjhfc)
* [How to make Streamgraph](https://youtu.be/Iu8Me9QO8mg)
* [How to make Sunburst Diagram](https://youtu.be/knqimV7RVbI)
* [How to make Voronoi Diagram](https://youtu.be/I7nn29giVug)
* [How to make Hexagonal Binning](https://youtu.be/Q03sVDj32l4)

[Previous

Actor Network Visualization](#/actor-network-visualization)

[Next

Data Storytelling](#/data-storytelling)