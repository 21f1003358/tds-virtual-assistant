---
title: "Data Storytelling"
original_url: "https://tds.s-anand.net/#/data-storytelling?id=data-storytelling"
downloaded_at: "2025-05-31T21:38:43.337343"
---

[Data Storytelling](#/data-storytelling?id=data-storytelling)
=============================================================

[![Narrate a story](https://i.ytimg.com/vi_webp/aF93i6zVVQg/sddefault.webp)](https://youtu.be/aF93i6zVVQg)

[Previous

RAWgraphs](#/rawgraphs)

[Next

Narratives with LLMs](#/narratives-with-llms)