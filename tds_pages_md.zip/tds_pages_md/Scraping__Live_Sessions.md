---
title: "Scraping: Live Sessions"
original_url: "https://tds.s-anand.net/#/scraping-live-sessions?id=scraping-live-sessions"
downloaded_at: "2025-05-31T21:39:30.556374"
---

[Scraping: Live Sessions](#/scraping-live-sessions?id=scraping-live-sessions)
-----------------------------------------------------------------------------

[![Intro to Web scraping and HTML](https://i.ytimg.com/vi_webp/cAriusuJsmw/sddefault.webp)](https://youtu.be/cAriusuJsmw)

Fundamentals of web scraping with urllib and BeautifulSoup

[![Fundamentals of web scraping with urllib and BeautifulSoup](https://i.ytimg.com/vi_webp/I3auyTYORTs/sddefault.webp)](https://youtu.be/I3auyTYORTs)

Intermediate web scraping use of cookies

[![Intermediate web scraping use of cookies](https://i.ytimg.com/vi_webp/DryMIxMf3VU/sddefault.webp)](https://youtu.be/DryMIxMf3VU)

XML intro and scraping

[![XML intro and scraping](https://i.ytimg.com/vi_webp/8S_jvsjtaYg/sddefault.webp)](https://youtu.be/8S_jvsjtaYg)

[Previous

Scraping emarketer.com](#/scraping-emarketer)

[Next

5. Data Preparation](#/data-preparation)